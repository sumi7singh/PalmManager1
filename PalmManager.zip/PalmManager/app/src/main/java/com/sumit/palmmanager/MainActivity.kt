package com.sumit.palmmanager

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.Year
import java.time.YearMonth
import java.time.temporal.ChronoUnit

// ---------- थीम / हेल्पर ----------
private const val UNIT = "₹/टन"
private val Orange = Color(0xFFE65100)
private val Red = Color(0xFFB23A1E)
private val Cream = Color(0xFFFFF3E0)
private val Green = Color(0xFF2E7D32)

private val TIPS = listOf(
    "ठंड/सूखा — पौधों के थाले साफ रखें और सिंचाई दें।",
    "सूखे में पानी की कमी न होने दें, मल्चिंग करें।",
    "खाद की पहली डोज़ सिफारिश के अनुसार डालने का समय।",
    "खरपतवार हटाएँ, थाले साफ करें।",
    "प्री-मानसून — जल निकासी (ड्रेनेज) जाँच लें।",
    "बारिश शुरू — पानी रुकने न दें, खाद की अगली डोज़ प्लान करें।",
    "भारी बारिश — पत्तों/गुच्छों की बीमारी पर नज़र रखें।",
    "पके गुच्छे समय पर काटें, देरी से नुकसान होता है।",
    "खाद की दूसरी डोज़ का सही समय।",
    "कटाई तेज़ — केवल पके (नारंगी-लाल) गुच्छे काटें।",
    "गिरे हुए ढीले फल बीनें, रास्ते साफ रखें।",
    "सूखे से पहले सिंचाई और मल्चिंग की तैयारी करें।"
)

private fun Map<String, String>.g(k: String) = this[k] ?: ""
private fun today() = LocalDate.now().toString()
private fun plusDays(d: String, n: Long) =
    try { LocalDate.parse(d).plusDays(n).toString() } catch (e: Exception) { LocalDate.now().plusDays(n).toString() }
private fun daysLeft(d: String) =
    try { ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(d)).toInt() } catch (e: Exception) { 9999 }

// ---------- डेटा स्टोरेज (फोन में लोकल) ----------
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("palm", Context.MODE_PRIVATE)
    fun load(key: String): List<Map<String, String>> {
        val arr = JSONArray(sp.getString(key, "[]"))
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            o.keys().asSequence().associateWith { o.getString(it) }
        }
    }
    fun save(key: String, l: List<Map<String, String>>) {
        sp.edit().putString(key, JSONArray(l.map { JSONObject(it) }).toString()).apply()
    }
}

class Table(private val store: Store, private val key: String) {
    val rows = mutableStateListOf<Map<String, String>>().also { it.addAll(store.load(key)) }
    private fun save() = store.save(key, rows.toList())
    fun add(m: Map<String, String>) { rows.add(0, m); save() }
    fun set(i: Int, m: Map<String, String>) { rows[i] = m; save() }
    fun del(i: Int) { rows.removeAt(i); save() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this)
        val s = Store(this)
        val plots = Table(s, "plots"); val yields = Table(s, "yield")
        val ferts = Table(s, "fert"); val rates = Table(s, "rates")
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Orange)) { App(plots, yields, ferts, rates) }
        }
    }
}

@Composable
fun App(plots: Table, yields: Table, ferts: Table, rates: Table) {
    var screen by remember { mutableStateOf("home") }
    BackHandler(screen != "home") { screen = "home" }
    Column(Modifier.fillMaxSize().background(Cream)) {
        Box(Modifier.weight(1f)) {
            when (screen) {
                "plots" -> PlotsScreen(plots)
                "harvest" -> HarvestScreen(plots, yields)
                "yield" -> YieldScreen(plots, yields)
                "fert" -> FertScreen(plots, ferts)
                "rate" -> RateScreen(rates)
                else -> Home(plots, yields) { screen = it }
            }
        }
        AdBanner()
    }
}

// ---------- छोटे UI पार्ट्स ----------
@Composable fun B(t: String, s: Int = 18, c: Color = Color.Unspecified) =
    Text(t, fontSize = s.sp, fontWeight = FontWeight.Bold, color = c)

@Composable
fun Screen(title: String, fab: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            B(title, 26, Red); Spacer(Modifier.height(12.dp)); content()
        }
        if (fab != null) FloatingActionButton(
            onClick = fab, containerColor = Orange,
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Text("+", fontSize = 28.sp, color = Color.White) }
    }
}

@Composable
fun Tile(mod: Modifier = Modifier, color: Color = Color.White, content: @Composable ColumnScope.() -> Unit) =
    Card(mod.fillMaxWidth(), RoundedCornerShape(16.dp), CardDefaults.cardColors(containerColor = color)) {
        Column(Modifier.padding(14.dp), content = content)
    }

@Composable
fun Form(title: String, onDismiss: () -> Unit, onOk: () -> Unit, content: @Composable ColumnScope.() -> Unit) =
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp), content = content) },
        confirmButton = { Button(onClick = onOk, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("सेव करें") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("रद्द") } }
    )

@Composable
fun Field(label: String, v: String, num: Boolean = false, set: (String) -> Unit) =
    OutlinedTextField(v, set, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (num) KeyboardType.Number else KeyboardType.Text))

@Composable
fun Stepper(v: Int, step: Int, set: (Int) -> Unit) =
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Button(onClick = { set((v - step).coerceAtLeast(0)) }) { Text("−", fontSize = 24.sp) }
        B("$v kg", 24)
        Button(onClick = { set(v + step) }) { Text("+", fontSize = 24.sp) }
    }

@Composable
fun PlotPicker(plots: Table, sel: String, set: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) { Text(if (sel.isEmpty()) "प्लॉट चुनें" else sel) }
        DropdownMenu(open, { open = false }) {
            plots.rows.forEach { p ->
                DropdownMenuItem(text = { Text(p.g("name")) }, onClick = { set(p.g("name")); open = false })
            }
        }
    }
}

@Composable
fun Bars(data: List<Pair<String, Float>>, zero: Boolean = true) {
    val mx = (data.maxOfOrNull { it.second } ?: 1f).coerceAtLeast(1f)
    val lo = if (zero) 0f else (data.minOfOrNull { it.second } ?: 0f) * 0.8f
    val span = (mx - lo).coerceAtLeast(1f)
    Row(Modifier.fillMaxWidth().height(130.dp), Arrangement.SpaceEvenly, Alignment.Bottom) {
        data.forEach { (l, v) ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                Box(Modifier.width(26.dp).height((90 * (v - lo) / span).dp + 2.dp).background(Orange, RoundedCornerShape(4.dp)))
                Text(l, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun AdBanner() = AndroidView(modifier = Modifier.fillMaxWidth(), factory = { c ->
    AdView(c).apply {
        setAdSize(AdSize.BANNER)
        adUnitId = "ca-app-pub-3940256099942544/6300978111" // TEST ID — बदलना है
        loadAd(AdRequest.Builder().build())
    }
})

// ---------- होम ----------
@Composable
fun RowScope.Stat(value: String, label: String) =
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) { B(value, 28, Green); Text(label, fontSize = 12.sp) }

@Composable
fun RowScope.Menu(icon: String, label: String, color: Color, onClick: () -> Unit) =
    Tile(Modifier.weight(1f).height(120.dp).clickable(onClick = onClick), color) {
        Text(icon, fontSize = 40.sp); B(label, 20)
    }

@Composable
fun Home(plots: Table, yields: Table, go: (String) -> Unit) {
    val ym = YearMonth.now().toString()
    val monthKg = yields.rows.filter { it.g("date").startsWith(ym) }.sumOf { it.g("kg").toIntOrNull() ?: 0 }
    val next = plots.rows.map { daysLeft(it.g("next")) }.filter { it < 9999 }.minOrNull()
    Screen("🌴 मेरा प्लांटेशन", fab = { go("yield") }) {
        Tile(Modifier.clickable { go("plots") }, Color(0xFFDCEDC8)) {
            Row {
                Stat("${plots.rows.size}", "प्लॉट")
                Stat("$monthKg", "इस महीने (kg)")
                Stat(next?.toString() ?: "—", "अगला हार्वेस्ट (दिन)")
            }
        }
        Spacer(Modifier.height(10.dp))
        Tile(color = Color(0xFFFFE082)) {
            Text("💡 इस महीने का सुझाव: ${TIPS[LocalDate.now().monthValue - 1]}", fontSize = 15.sp)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Menu("🧺", "हार्वेस्ट", Color(0xFFFFCC80)) { go("harvest") }
            Menu("📈", "यील्ड", Color(0xFFC5E1A5)) { go("yield") }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Menu("🌱", "खाद", Color(0xFFFFAB91)) { go("fert") }
            Menu("💰", "भाव", Color(0xFFFFF59D)) { go("rate") }
        }
    }
}

// ---------- प्लॉट्स ----------
@Composable
fun PlotsScreen(plots: Table) {
    var add by remember { mutableStateOf(false) }
    var n by remember { mutableStateOf("") }; var a by remember { mutableStateOf("") }; var g by remember { mutableStateOf("15") }
    Screen("मेरे प्लॉट्स", fab = { add = true }) {
        if (plots.rows.isEmpty()) Text("+ दबाकर पहला प्लॉट जोड़ें")
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(plots.rows) { i, p ->
                val d = daysLeft(p.g("next"))
                val c = if (d < 0) Color.Red else if (d <= 3) Color(0xFFFFB300) else Green
                Tile {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            B(p.g("name"), 20)
                            Text("${p.g("area")} एकड़ • पिछला: ${p.g("last").ifEmpty { "—" }}")
                            Text("अगला हार्वेस्ट: ${p.g("next")} ($d दिन)")
                        }
                        Box(Modifier.size(20.dp).background(c, CircleShape))
                        TextButton(onClick = { plots.del(i) }) { Text("🗑") }
                    }
                }
            }
        }
        if (add) Form("नया प्लॉट", { add = false }, {
            if (n.isNotBlank()) plots.add(mapOf("name" to n, "area" to a, "gap" to g, "last" to "",
                "next" to plusDays(today(), g.toLongOrNull() ?: 15)))
            n = ""; a = ""; add = false
        }) {
            Field("प्लॉट का नाम", n) { n = it }
            Field("एरिया (एकड़)", a, true) { a = it }
            Field("हार्वेस्ट अंतराल (दिन)", g, true) { g = it }
        }
    }
}

// ---------- हार्वेस्ट ----------
@Composable
fun HarvestScreen(plots: Table, yields: Table) {
    var sel by remember { mutableStateOf<Int?>(null) }
    var kg by remember { mutableStateOf(0) }
    Screen("हार्वेस्ट") {
        if (plots.rows.isEmpty()) Text("पहले प्लॉट जोड़ें")
        val order = plots.rows.withIndex().sortedBy { daysLeft(it.value.g("next")) }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(order) { iv ->
                val p = iv.value
                Tile {
                    B(p.g("name"), 20)
                    Text("अगला: ${p.g("next")} — ${daysLeft(p.g("next"))} दिन बचे", fontSize = 16.sp)
                    Spacer(Modifier.height(6.dp))
                    Button(onClick = { sel = iv.index; kg = 0 }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                        Text("✔ हार्वेस्ट पूरा हुआ")
                    }
                }
            }
        }
        val s = sel
        if (s != null) Form("उपज दर्ज करें", { sel = null }, {
            val p = plots.rows[s]
            yields.add(mapOf("plot" to p.g("name"), "date" to today(), "kg" to kg.toString()))
            plots.set(s, p + mapOf("last" to today(), "next" to plusDays(today(), p.g("gap").toLongOrNull() ?: 15)))
            sel = null
        }) { Stepper(kg, 50) { kg = it } }
    }
}

// ---------- यील्ड ----------
@Composable
fun YieldScreen(plots: Table, yields: Table) {
    var add by remember { mutableStateOf(false) }
    var plot by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(today()) }
    var kg by remember { mutableStateOf(0) }
    val year = Year.now().toString()
    val total = yields.rows.filter { it.g("date").startsWith(year) }.sumOf { it.g("kg").toIntOrNull() ?: 0 }
    val data = (5 downTo 0).map { YearMonth.now().minusMonths(it.toLong()) }.map { m ->
        m.monthValue.toString() to yields.rows.filter { it.g("date").startsWith(m.toString()) }
            .sumOf { it.g("kg").toIntOrNull() ?: 0 }.toFloat()
    }
    Screen("यील्ड ट्रैकर", fab = { add = true }) {
        B("इस साल: $total kg", 30, Green)
        Spacer(Modifier.height(8.dp)); Bars(data); Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(yields.rows) { i, y ->
                Tile {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("${y.g("plot")} • ${y.g("date")}"); B("${y.g("kg")} kg", 20) }
                        TextButton(onClick = { yields.del(i) }) { Text("🗑") }
                    }
                }
            }
        }
        if (add) Form("नई उपज", { add = false }, {
            if (plot.isNotEmpty() && kg > 0) yields.add(mapOf("plot" to plot, "date" to date, "kg" to kg.toString()))
            kg = 0; add = false
        }) {
            PlotPicker(plots, plot) { plot = it }
            Field("तारीख (YYYY-MM-DD)", date) { date = it }
            Stepper(kg, 50) { kg = it }
        }
    }
}

// ---------- खाद ----------
@Composable
fun FertScreen(plots: Table, ferts: Table) {
    var tab by remember { mutableStateOf(0) }
    var add by remember { mutableStateOf(false) }
    var plot by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }; var date by remember { mutableStateOf(today()) }
    var gap by remember { mutableStateOf("90") }
    Screen("खाद शेड्यूल", fab = { add = true }) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("आने वाला") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("पूरा हुआ") })
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(ferts.rows) { i, f ->
                if ((f.g("done") == "1") == (tab == 1)) Tile {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            B("${f.g("plot")} — ${f.g("date")}", 17)
                            Text("${f.g("name")} • ${f.g("qty")}")
                        }
                        if (tab == 0) Button(onClick = {
                            ferts.set(i, f + ("done" to "1"))
                            ferts.add(f + mapOf("done" to "0", "date" to plusDays(f.g("date"), f.g("gap").toLongOrNull() ?: 90)))
                        }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("✔ खाद डाल दी") }
                        else TextButton(onClick = { ferts.del(i) }) { Text("🗑") }
                    }
                }
            }
        }
        if (add) Form("नया खाद शेड्यूल", { add = false }, {
            if (plot.isNotEmpty() && name.isNotBlank()) ferts.add(mapOf("plot" to plot, "name" to name,
                "qty" to qty, "date" to date, "gap" to gap, "done" to "0"))
            name = ""; qty = ""; add = false
        }) {
            PlotPicker(plots, plot) { plot = it }
            Field("खाद का नाम", name) { name = it }
            Field("मात्रा (प्रति पेड़)", qty) { qty = it }
            Field("तारीख (YYYY-MM-DD)", date) { date = it }
            Field("दोबारा कितने दिन बाद", gap, true) { gap = it }
        }
    }
}

// ---------- भाव ----------
@Composable
fun RateScreen(rates: Table) {
    val types = listOf("intl" to "इंटरनेशनल रेट", "govt" to "सरकारी VGP रेट", "co" to "कंपनी रेट")
    var sel by remember { mutableStateOf("intl") }
    var edit by remember { mutableStateOf<String?>(null) }
    var rate by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(today()) }
    Screen("भाव") {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            types.forEach { (t, label) ->
                val h = rates.rows.filter { it.g("type") == t }.sortedByDescending { it.g("date") }
                val cur = h.firstOrNull()?.g("rate")?.toFloatOrNull()
                val prev = h.getOrNull(1)?.g("rate")?.toFloatOrNull()
                Tile(Modifier.clickable { sel = t }, if (t == sel) Color(0xFFFFCC80) else Color.White) {
                    Text(label, fontSize = 16.sp)
                    val arrow = if (cur != null && prev != null) (if (cur >= prev) " ▲" else " ▼") else ""
                    B(if (cur == null) "—" else "₹ ${cur.toString().removeSuffix(".0")}$arrow", 30, Red)
                    Text("$UNIT • ${h.firstOrNull()?.g("date") ?: "रेट दर्ज नहीं"}", fontSize = 12.sp)
                    Button(onClick = { edit = t; rate = ""; date = today() }) { Text("अपडेट करें") }
                }
            }
            val hist = rates.rows.filter { it.g("type") == sel }.sortedBy { it.g("date") }
            B("साल भर का इतिहास — ${types.first { it.first == sel }.second}", 18)
            Bars(hist.takeLast(12).map { it.g("date").drop(5).take(2) to (it.g("rate").toFloatOrNull() ?: 0f) }, zero = false)
            hist.reversed().forEach { r ->
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text(r.g("date")); Text("₹ ${r.g("rate")}")
                    TextButton(onClick = { rates.del(rates.rows.indexOf(r)) }) { Text("🗑") }
                }
            }
        }
        val e = edit
        if (e != null) Form("रेट अपडेट", { edit = null }, {
            if (rate.isNotBlank()) rates.add(mapOf("type" to e, "date" to date, "rate" to rate))
            edit = null
        }) {
            Field("रेट ($UNIT)", rate, true) { rate = it }
            Field("तारीख (YYYY-MM-DD)", date) { date = it }
        }
    }
}
